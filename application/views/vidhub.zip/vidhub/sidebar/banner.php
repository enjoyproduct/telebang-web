<div class="siderbar-banner">
	<div class="item-banner">
		<span>Tips & Tricks</span>
		<h4>New Ideas For A Low Cost Vacation On Water</h4>
		<a href="http://store.inspius.com/downloads/category/yo-collection/" target="_blank" class="btn">FIND OUT MORE</a>
	</div>
</div>